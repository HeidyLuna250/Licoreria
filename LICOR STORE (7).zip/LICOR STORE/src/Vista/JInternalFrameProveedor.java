package Vista;
import Modeloo.Proveedor;
import Modeloo.DAOProveedor;
import java.awt.HeadlessException;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*** @author Lcoreria
 */
public class JInternalFrameProveedor extends javax.swing.JInternalFrame {

    /***/
    public JInternalFrameProveedor() {
        initComponents();
        jTextIdProveedor.setEditable(false);
        obtenerDatos();
    }
    
    public void obtenerDatos(){ 
        try {

            List<Proveedor> proveedores =new DAOProveedor().ObtenerDatos();

            DefaultTableModel modelo =new DefaultTableModel();

            String[] columnas = {
                "Codigo_Proveedor", 
                "Nombre", 
                "Apellido", 
                "Telefono", 
                "Empresa", 
                "Direccion"};

            modelo.setColumnIdentifiers(columnas);
            for (Proveedor pro : proveedores){
                
                String[] renglon ={Integer.toString(pro.getCodigo_Proveedor()),
                    pro.getNombre(),pro.getApellido(),pro.getTelefono(),pro.getEmpresa(),
                    pro.getDireccion() };
                modelo.addRow(renglon);
            }
           jTable_Proveedores.setModel(modelo);
        } catch (SQLException ex) {
            Logger.getLogger(JInternalFrameProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
         }
        
    public void actualizarProveedores() throws SQLException {
       int id = Integer.parseInt(this.jTextIdProveedor.getText());
       String nom = this.jTextNombres.getText();
       String ape = this.jTextApellidos.getText();
       String tel = this.jTextTelefono.getText();
       String emp = this.jText_Empresa.getText();
       String direc = this.jTextDireccion.getText();
       
       Proveedor proveedor = new Proveedor(id, nom, ape, tel,
               emp, direc);
       
       DAOProveedor dao = new DAOProveedor();
       int res = dao.Actualizar(proveedor);
       if (res == 0) {
           JOptionPane.showMessageDialog(rootPane,
                   "¡Proveedor Actualizado!");
       } else {
           JOptionPane.showMessageDialog(rootPane,
                   "¡Ocurrio un ERROR!");
       }     
       } 
       
         public void limpiarCampos(){
        // Este método limpia los campos de la interfaz gráfica.
// Establece valores vacíos o nulos en varios componentes de la interfaz
        
// Establece el texto de los campos de texto a valores vacíos
        jTextIdProveedor.setText("");
        jTextNombres.setText("");
        jTextApellidos.setText("");
        jTextTelefono.setText("");
        jText_Empresa.setText("");
        jTextDireccion.setText("");
   
    }

    /***/
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Proveedores = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextDireccion = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jTextIdProveedor = new javax.swing.JTextField();
        jText_Empresa = new javax.swing.JTextField();
        jTextApellidos = new javax.swing.JTextField();
        jTextNombres = new javax.swing.JTextField();
        jTextTelefono = new javax.swing.JFormattedTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jBAgregar1 = new javax.swing.JButton();
        jBBorrar1 = new javax.swing.JButton();
        jTextFiltrar1 = new javax.swing.JTextField();
        jBBuscar1 = new javax.swing.JButton();
        JBEditar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jPanel15 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(204, 102, 0));
        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);

        jPanel1.setBackground(new java.awt.Color(202, 125, 48));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel7.setBackground(new java.awt.Color(202, 125, 48));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Lista de Proveedores", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 24))); // NOI18N
        jPanel7.setForeground(new java.awt.Color(204, 102, 0));
        jPanel7.setName(""); // NOI18N
        jPanel7.setLayout(new javax.swing.OverlayLayout(jPanel7));

        jTable_Proveedores.setBackground(new java.awt.Color(232, 232, 232));
        jTable_Proveedores.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTable_Proveedores.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTable_Proveedores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombres", "Apellidos", "Teléfonos", "Empresas", "Direcciones"
            }
        ));
        jTable_Proveedores.setGridColor(new java.awt.Color(204, 102, 0));
        jScrollPane1.setViewportView(jTable_Proveedores);

        jPanel7.add(jScrollPane1);

        jPanel3.setBackground(new java.awt.Color(204, 102, 0));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel3.setOpaque(false);

        jLabel3.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Nombres");

        jLabel9.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Apellidos");

        jLabel7.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Dirección");

        jLabel5.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Teléfono");

        jLabel8.setBackground(new java.awt.Color(0, 0, 0));
        jLabel8.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("ID_Proveedor");

        jTextDireccion.setBackground(new java.awt.Color(232, 232, 232));
        jTextDireccion.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextDireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextDireccionActionPerformed(evt);
            }
        });
        jTextDireccion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextDireccionKeyTyped(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Empresa");

        jTextIdProveedor.setBackground(new java.awt.Color(232, 232, 232));
        jTextIdProveedor.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jText_Empresa.setBackground(new java.awt.Color(232, 232, 232));
        jText_Empresa.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jText_Empresa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jText_EmpresaKeyTyped(evt);
            }
        });

        jTextApellidos.setBackground(new java.awt.Color(232, 232, 232));
        jTextApellidos.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextApellidos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextApellidosKeyTyped(evt);
            }
        });

        jTextNombres.setBackground(new java.awt.Color(232, 232, 232));
        jTextNombres.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextNombres.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextNombresKeyTyped(evt);
            }
        });

        jTextTelefono.setBackground(new java.awt.Color(232, 232, 232));
        jTextTelefono.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        try {
            jTextTelefono.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextIdProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(6, 6, 6)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextNombres, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextApellidos, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(74, 74, 74))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jTextTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jText_Empresa, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(73, 73, 73)
                        .addComponent(jLabel7)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5)
                    .addComponent(jLabel10)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTextIdProveedor, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jText_Empresa, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTextNombres)
                    .addComponent(jTextApellidos)
                    .addComponent(jTextTelefono)
                    .addComponent(jTextDireccion, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
                .addContainerGap(34, Short.MAX_VALUE))
        );

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Logis.jpg"))); // NOI18N

        jPanel4.setBackground(new java.awt.Color(202, 125, 48));
        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jBAgregar1.setBackground(new java.awt.Color(182, 182, 188));
        jBAgregar1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBAgregar1.setForeground(new java.awt.Color(182, 182, 188));
        jBAgregar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jBAgregar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBAgregar1ActionPerformed(evt);
            }
        });

        jBBorrar1.setBackground(new java.awt.Color(182, 182, 188));
        jBBorrar1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBBorrar1.setForeground(new java.awt.Color(182, 182, 188));
        jBBorrar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/eliminar.png"))); // NOI18N
        jBBorrar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jBBorrar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBBorrar1ActionPerformed(evt);
            }
        });

        jTextFiltrar1.setBackground(new java.awt.Color(232, 232, 232));
        jTextFiltrar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFiltrar1ActionPerformed(evt);
            }
        });

        jBBuscar1.setBackground(new java.awt.Color(182, 182, 188));
        jBBuscar1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBBuscar1.setForeground(new java.awt.Color(182, 182, 188));
        jBBuscar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/buscar.png"))); // NOI18N
        jBBuscar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jBBuscar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBBuscar1ActionPerformed(evt);
            }
        });

        JBEditar.setBackground(new java.awt.Color(182, 182, 188));
        JBEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/editar.png"))); // NOI18N
        JBEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBEditarActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(182, 182, 188));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Actualizar.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jBAgregar1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jTextFiltrar1, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jBBuscar1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(JBEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jBBorrar1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 85, Short.MAX_VALUE)))
                        .addGap(0, 34, Short.MAX_VALUE))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(jBAgregar1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(JBEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jBBorrar1, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextFiltrar1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBBuscar1, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18))
        );

        jPanel15.setBackground(new java.awt.Color(255, 204, 102));
        jPanel15.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel16.setText("Registro de Proveedores");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(430, 430, 430)
                        .addComponent(jLabel15))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(353, 353, 353)
                        .addComponent(jLabel16)))
                .addContainerGap(597, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(jLabel15)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(82, 82, 82)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(3, 3, 3)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(65, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1310, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextDireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextDireccionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextDireccionActionPerformed

    private void jTextDireccionKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextDireccionKeyTyped

    }//GEN-LAST:event_jTextDireccionKeyTyped

    private void jTextApellidosKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextApellidosKeyTyped

    }//GEN-LAST:event_jTextApellidosKeyTyped

    private void jTextNombresKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextNombresKeyTyped

    }//GEN-LAST:event_jTextNombresKeyTyped

    private void jBAgregar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBAgregar1ActionPerformed
          //Captura datos de la caja de texto
        String nomb = jTextNombres.getText();
        String apell = jTextApellidos.getText();
        String tel = jTextTelefono.getText();
        String emp = jText_Empresa.getText();
        String direc = jTextDireccion.getText();
        // Agregar validacines a cajas de texto segun fromato y
        // caracteres validos a ingresar
        // comprueba que las cajas de texto no esten vacias 
        if (nomb.contentEquals("") || apell.contentEquals("")
                || tel.contentEquals("") || emp.contentEquals("")
                || direc.contentEquals("")) {
            JOptionPane.showMessageDialog(rootPane,
                    "Todos los campos son obligatorios de llenar");
        } else {
            try {
                //Objeto para pasar valores a método Insertar de DAOAutor
                Proveedor proveedor = new Proveedor(nomb, apell,
                        tel, emp, direc);
                DAOProveedor dao = new DAOProveedor();
                if (dao.Insertar(proveedor) == 0) {
                    JOptionPane.showMessageDialog(rootPane,
                            "Proveedor agregado");
                }
                
            } catch (HeadlessException | SQLException e) {
                JOptionPane.showMessageDialog(rootPane,
                        "No se agrego el Proveedor");
            }
            
        }
        obtenerDatos(); //Llama a este metodo para que se muestre el nuevo
        //Registro en la tabla del formulario
        limpiarCampos();   //Llama a este metodo para limpiar las cajas de texto
    }//GEN-LAST:event_jBAgregar1ActionPerformed

    private void jBBorrar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBBorrar1ActionPerformed
        // Este método se activa al hacer clic en el botón "Borrar" en la interfaz.
    // Obtiene la fila seleccionada en la tabla jTable_Autor.
        int fila = this.jTable_Proveedores.getSelectedRow();
if (fila ==-1){
    // Si no se ha seleccionado ninguna fila, muestra un mensaje de advertencia.
    JOptionPane.showMessageDialog(rootPane,
            "Seleccione un proveedor de la tabla");
} else {
 
    JDialog.setDefaultLookAndFeelDecorated(true);
    int resp = JOptionPane.showConfirmDialog(null,
            "¿Esta seguro de eliminar este proveedor?", "Aceptar" 
            ,JOptionPane.YES_NO_OPTION
            ,JOptionPane.QUESTION_MESSAGE);
         if(resp == JOptionPane.NO_OPTION) { 
             JOptionPane.showMessageDialog(rootPane, 
                     "proveedor no borrado");
         }else {
             if (resp == JOptionPane.YES_OPTION) {
               try {
                   int id = Integer.parseInt((String) this.jTable_Proveedores.
                           getValueAt(fila, 0).toString());
                             DAOProveedor dao = new DAOProveedor();
                             dao.Eliminar (id);
                             obtenerDatos();
                     } catch (SQLException ex) {
                         Logger.getLogger( JInternalFrameProveedor.class.getName()).
                               log(Level.SEVERE,null,ex);
                     }
             }
         }
            if (resp == JOptionPane.CLOSED_OPTION) {
            JOptionPane.showMessageDialog(rootPane, 
                    "Ninguna acción realizada");
   }
    
   }
    }//GEN-LAST:event_jBBorrar1ActionPerformed

    private void jTextFiltrar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFiltrar1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFiltrar1ActionPerformed

    private void jBBuscar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBBuscar1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jBBuscar1ActionPerformed

    private void jText_EmpresaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jText_EmpresaKeyTyped

    }//GEN-LAST:event_jText_EmpresaKeyTyped

    private void JBEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBEditarActionPerformed
    int fila = this.jTable_Proveedores.getSelectedRow();
    if (fila == -1) {
        JOptionPane.showMessageDialog(rootPane, "Seleccione un registro de la tabla");
    } else {
        try { 
            int id = Integer.parseInt((String) this.jTable_Proveedores.getValueAt(fila, 0).toString());
            String nom = (String) this.jTable_Proveedores.getValueAt(fila, 1);
            String ape = (String) this.jTable_Proveedores.getValueAt(fila, 2);
            String tel = (String)this.jTable_Proveedores.getValueAt(fila, 3);
            String emp = (String) this.jTable_Proveedores.getValueAt(fila, 4);
            String direc = (String) this.jTable_Proveedores.getValueAt(fila, 5);

            jTextIdProveedor.setText("" + id);
            jTextNombres.setText(nom);
            jTextApellidos.setText(ape);
            jTextTelefono.setText(tel);
            jText_Empresa.setText(emp);
            jTextDireccion.setText(direc);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(rootPane,
                    "Ocurrió un error "+e.getMessage());
        }
    }
    }//GEN-LAST:event_JBEditarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
try {
    actualizarProveedores();
} catch (SQLException ex) {
    Logger.getLogger(JInternalFrameProveedor.class.getName()).
            log(Level.SEVERE, null, ex);
}
obtenerDatos();
limpiarCampos();
    
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JBEditar;
    private javax.swing.JButton jBAgregar1;
    private javax.swing.JButton jBBorrar1;
    private javax.swing.JButton jBBuscar1;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_Proveedores;
    private javax.swing.JTextField jTextApellidos;
    private javax.swing.JTextField jTextDireccion;
    private javax.swing.JTextField jTextFiltrar1;
    private javax.swing.JTextField jTextIdProveedor;
    private javax.swing.JTextField jTextNombres;
    private javax.swing.JFormattedTextField jTextTelefono;
    private javax.swing.JTextField jText_Empresa;
    // End of variables declaration//GEN-END:variables
}
