package Vista;
import Modeloo.DAOEmpleado;
import Modeloo.Empleado;
import java.awt.HeadlessException;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*** @author Licoreria
 */
public class JInternalFrameEmpleado extends javax.swing.JInternalFrame {

    /***/
    public JInternalFrameEmpleado() {
        initComponents();
         jTextIdEmpleado.setEditable(false);
        obtenerDatos();
    }
    
     public void obtenerDatos(){ 
        try {
            List<Empleado> Empleados =new DAOEmpleado().ObtenerDatos();
            DefaultTableModel modelo =new DefaultTableModel();
            
            String[] columnas = {
                "Codigo_Empleado", 
                "Nombre", 
                "Apellido", 
                "CedulaEmpleado"};

            modelo.setColumnIdentifiers(columnas);
            for (Empleado em : Empleados){
                String[] renglon ={Integer.toString(em.getCodigo_Empleado()),
                     em.getNombre(),
                     em.getApellido(),
                     em.getCedulaEmpleado() };
                modelo.addRow(renglon);
            }
           jTable_Empleados.setModel(modelo);//Ubica los datos del modelo en la tabla
        } catch (SQLException ex) {
            Logger.getLogger(JInternalFrameEmpleado.class.getName()).log(Level.SEVERE, null, ex);
        }
         }
        
         public void actualizarEmpleados() throws SQLException {
       int id = Integer.parseInt(this.jTextIdEmpleado.getText());
       String nom = this.jTextNombres.getText();
       String ape = this.jTextApellidos.getText();
       String ced = this.jTextCedula.getText();
       
       Empleado empleados = new Empleado(id, nom, ape, ced);
       DAOEmpleado dao = new DAOEmpleado();
       int res = dao.Actualizar(empleados);
       if (res == 0) {
           JOptionPane.showMessageDialog(rootPane,
                   "¡Empleado Actualizado!");
       } else {
           JOptionPane.showMessageDialog(rootPane,
                   "¡Ocurrio un ERROR!");
       }     
       } 
       
         public void limpiarCampos(){
        // Este método limpia los campos de la interfaz gráfica.
// Establece valores vacíos o nulos en varios componentes de la interfaz
        
// Establece el texto de los campos de texto a valores vacíos
        jTextIdEmpleado.setText("");
        jTextNombres.setText("");
        jTextApellidos.setText("");
        jTextCedula.setText("");
   
    }

    /***/
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Empleados = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextIdEmpleado = new javax.swing.JTextField();
        jTextApellidos = new javax.swing.JTextField();
        jTextNombres = new javax.swing.JTextField();
        jTextCedula = new javax.swing.JFormattedTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jBAgregar1 = new javax.swing.JButton();
        jBEditar1 = new javax.swing.JButton();
        jBactualizar1 = new javax.swing.JButton();
        jBBorrar1 = new javax.swing.JButton();
        jTextFiltrar1 = new javax.swing.JTextField();
        jBBuscar1 = new javax.swing.JButton();
        jPanel15 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);

        jPanel1.setBackground(new java.awt.Color(204, 102, 0));

        jPanel7.setBackground(new java.awt.Color(204, 102, 0));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Lista de Empleados", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 24))); // NOI18N
        jPanel7.setForeground(new java.awt.Color(204, 102, 0));
        jPanel7.setLayout(new javax.swing.OverlayLayout(jPanel7));

        jTable_Empleados.setBackground(new java.awt.Color(232, 232, 232));
        jTable_Empleados.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTable_Empleados.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTable_Empleados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Nombres", "Apellidos", "Cédulas"
            }
        ));
        jTable_Empleados.setGridColor(new java.awt.Color(204, 102, 0));
        jScrollPane1.setViewportView(jTable_Empleados);

        jPanel7.add(jScrollPane1);

        jPanel3.setBackground(new java.awt.Color(204, 102, 0));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel3.setOpaque(false);

        jLabel3.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Nombres");

        jLabel9.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Apellidos");

        jLabel8.setBackground(new java.awt.Color(0, 0, 0));
        jLabel8.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("ID_Empleado");

        jLabel10.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Cédula");

        jTextIdEmpleado.setBackground(new java.awt.Color(232, 232, 232));
        jTextIdEmpleado.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jTextApellidos.setBackground(new java.awt.Color(232, 232, 232));
        jTextApellidos.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextApellidos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextApellidosKeyTyped(evt);
            }
        });

        jTextNombres.setBackground(new java.awt.Color(232, 232, 232));
        jTextNombres.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextNombres.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextNombresKeyTyped(evt);
            }
        });

        jTextCedula.setBackground(new java.awt.Color(232, 232, 232));
        jTextCedula.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        try {
            jTextCedula.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###-######-####U")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextIdEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(39, 39, 39)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextNombres, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextApellidos, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(38, 38, 38)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(jTextCedula, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel3)
                    .addComponent(jLabel10)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextIdEmpleado, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(jTextNombres, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTextApellidos)
                    .addComponent(jTextCedula))
                .addGap(36, 36, 36))
        );

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Logis.jpg"))); // NOI18N

        jPanel4.setBackground(new java.awt.Color(204, 102, 0));
        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jBAgregar1.setBackground(new java.awt.Color(182, 182, 188));
        jBAgregar1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBAgregar1.setForeground(new java.awt.Color(182, 182, 188));
        jBAgregar1.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Documents\\NetBeansProjects\\Licoreria\\src\\Icon\\agregar.png")); // NOI18N
        jBAgregar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jBAgregar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBAgregar1ActionPerformed(evt);
            }
        });

        jBEditar1.setBackground(new java.awt.Color(182, 182, 188));
        jBEditar1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBEditar1.setForeground(new java.awt.Color(182, 182, 188));
        jBEditar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/editar.png"))); // NOI18N
        jBEditar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jBEditar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBEditar1ActionPerformed(evt);
            }
        });

        jBactualizar1.setBackground(new java.awt.Color(182, 182, 188));
        jBactualizar1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBactualizar1.setForeground(new java.awt.Color(182, 182, 188));
        jBactualizar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Actualizar.png"))); // NOI18N
        jBactualizar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jBactualizar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBactualizar1ActionPerformed(evt);
            }
        });

        jBBorrar1.setBackground(new java.awt.Color(182, 182, 188));
        jBBorrar1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBBorrar1.setForeground(new java.awt.Color(182, 182, 188));
        jBBorrar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/eliminar.png"))); // NOI18N
        jBBorrar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jBBorrar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBBorrar1ActionPerformed(evt);
            }
        });

        jTextFiltrar1.setBackground(new java.awt.Color(232, 232, 232));
        jTextFiltrar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFiltrar1ActionPerformed(evt);
            }
        });

        jBBuscar1.setBackground(new java.awt.Color(182, 182, 188));
        jBBuscar1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBBuscar1.setForeground(new java.awt.Color(182, 182, 188));
        jBBuscar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/buscar.png"))); // NOI18N
        jBBuscar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jBBuscar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBBuscar1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jBAgregar1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jTextFiltrar1, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jBBuscar1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jBBorrar1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jBEditar1, javax.swing.GroupLayout.DEFAULT_SIZE, 85, Short.MAX_VALUE)
                                .addComponent(jBactualizar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(0, 34, Short.MAX_VALUE))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jBBuscar1))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(jBAgregar1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 81, Short.MAX_VALUE)
                        .addComponent(jBEditar1, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(jBactualizar1, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jBBorrar1, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31)
                        .addComponent(jTextFiltrar1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18))
        );

        jPanel15.setBackground(new java.awt.Color(255, 204, 102));
        jPanel15.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel16.setText("Registro de Empleados");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(430, 430, 430)
                        .addComponent(jLabel15))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(353, 353, 353)
                        .addComponent(jLabel16)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(jLabel15)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(55, 55, 55)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(146, Short.MAX_VALUE))
                    .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(61, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextApellidosKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextApellidosKeyTyped

    }//GEN-LAST:event_jTextApellidosKeyTyped

    private void jTextNombresKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextNombresKeyTyped

    }//GEN-LAST:event_jTextNombresKeyTyped

    private void jBAgregar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBAgregar1ActionPerformed

        String nomb = jTextNombres.getText();
        String apell = jTextApellidos.getText();
        String ced = jTextCedula.getText();
        // Agregar validacines a cajas de texto segun fromato y
        // caracteres validos a ingresar
        // comprueba que las cajas de texto no esten vacias 
        if (nomb.contentEquals("") || apell.contentEquals("")
                || ced.contentEquals("")) {
            JOptionPane.showMessageDialog(rootPane,
                    "Todos los campos son obligatorios de llenar");
        } else {
            try {
                //Objeto para pasar valores a método Insertar de DAOAutor
                Empleado empleado = new Empleado(nomb, apell, 
                        ced);
                DAOEmpleado dao = new DAOEmpleado();
                if (dao.Insertar(empleado) == 0) {
                    JOptionPane.showMessageDialog(rootPane,
                            "Proveedor agregado");
                }
                
            } catch (HeadlessException | SQLException e) {
                JOptionPane.showMessageDialog(rootPane,
                        "No se agrego el Proveedor");
            }
            
        }
        obtenerDatos(); //Llama a este metodo para que se muestre el nuevo
        //Registro en la tabla del formulario
        limpiarCampos();   //Llama a este metodo para limpiar las cajas de texto
    }//GEN-LAST:event_jBAgregar1ActionPerformed

    private void jBEditar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBEditar1ActionPerformed
         // Este método se activa al hacer clic en un botón (jBEditar) en la interfaz.
// Selecciona un registro de la tabla y permite editar sus detalles.
    // Obtiene la fila seleccionada en la tabla jTable_Autor
        int fila = this.jTable_Empleados.getSelectedRow(); //Se obtiene @fila seleccionado
    if(fila == -1) {
        // Si no se selecciona ninguna fila, muestra un mensaje de advertencia
        JOptionPane.showMessageDialog(rootPane, 
                "Seleccione un empleado de la tabla");
    } else { //Se toma cada campo de la tabla del registro seleccionado 
        // Y se asigna a una variable 
                 try {
// Obtiene los datos de la fila seleccionada en la tabla y los muestra 
// en los campos de la interfaz
int id = Integer.parseInt((String)this.jTable_Empleados.
        getValueAt(fila, 0).toString());
        String nom = (String) this.jTable_Empleados.getValueAt(fila,1);
        String ape = (String) this.jTable_Empleados.getValueAt(fila,2);
        String ced = (String) this.jTable_Empleados.getValueAt(fila,3);
             
// Se ubican en las cajas de txtos los datos capturados de la tabla 
                jTextIdEmpleado.setText("" +id);
                jTextNombres.setText(nom);
                jTextApellidos.setText(ape);
                jTextCedula.setText(ced);
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(rootPane,
                            "¡Ocurrió un ERROR! "+e.getMessage());
             }
   }
    }//GEN-LAST:event_jBEditar1ActionPerformed

    private void jBactualizar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBactualizar1ActionPerformed
          try {
            actualizarEmpleados();
         } catch (SQLException ex) {
             Logger.getLogger(JInternalFrameEmpleado.class.getName()).
                     log(Level.SEVERE, null, ex);
         } 
        obtenerDatos(); 
        limpiarCampos();
    }//GEN-LAST:event_jBactualizar1ActionPerformed

    private void jBBorrar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBBorrar1ActionPerformed
        // Este método se activa al hacer clic en el botón "Borrar" en la interfaz.
    // Obtiene la fila seleccionada en la tabla jTable_Autor.
        int fila = this.jTable_Empleados.getSelectedRow();
if (fila ==-1){
    // Si no se ha seleccionado ninguna fila, muestra un mensaje de advertencia.
    JOptionPane.showMessageDialog(rootPane,
            "Seleccione un empleado de la tabla");
} else {
 
    JDialog.setDefaultLookAndFeelDecorated(true);
    int resp = JOptionPane.showConfirmDialog(null,
            "¿Esta seguro de eliminar este empleado?", "Aceptar" 
            ,JOptionPane.YES_NO_OPTION
            ,JOptionPane.QUESTION_MESSAGE);
         if(resp == JOptionPane.NO_OPTION) { 
             JOptionPane.showMessageDialog(rootPane, 
                     "Empleado no borrado");
         }else {
             if (resp == JOptionPane.YES_OPTION) {
               try {
                   int id = Integer.parseInt((String) this.jTable_Empleados.
                           getValueAt(fila, 0).toString());
                             DAOEmpleado dao = new DAOEmpleado();
                             dao.Eliminar (id);
                             obtenerDatos();
                     } catch (SQLException ex) {
                         Logger.getLogger( JInternalFrameEmpleado.class.getName()).
                               log(Level.SEVERE,null,ex);
                     }
             }
         }
            if (resp == JOptionPane.CLOSED_OPTION) {
            JOptionPane.showMessageDialog(rootPane, 
                    "Ninguna acción realizada");
   }
    
   }
    }//GEN-LAST:event_jBBorrar1ActionPerformed

    private void jTextFiltrar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFiltrar1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFiltrar1ActionPerformed

    private void jBBuscar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBBuscar1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jBBuscar1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBAgregar1;
    private javax.swing.JButton jBBorrar1;
    private javax.swing.JButton jBBuscar1;
    private javax.swing.JButton jBEditar1;
    private javax.swing.JButton jBactualizar1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_Empleados;
    private javax.swing.JTextField jTextApellidos;
    private javax.swing.JFormattedTextField jTextCedula;
    private javax.swing.JTextField jTextFiltrar1;
    private javax.swing.JTextField jTextIdEmpleado;
    private javax.swing.JTextField jTextNombres;
    // End of variables declaration//GEN-END:variables
}
