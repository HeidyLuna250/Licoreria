package Modeloo;

/*** @author Licoreria
 */
public class Empleado {
    private int Codigo_Empleado;
    private String Nombre;
    private String Apellido;
    private String CedulaEmpleado;

    public Empleado(int Codigo_Empleado, String Nombre, String Apellido, 
            String CedulaEmpleado) {
        this.Codigo_Empleado = Codigo_Empleado;
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.CedulaEmpleado = CedulaEmpleado;
    }

    public Empleado(String Nombre, String Apellido, String CedulaEmpleado) {
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.CedulaEmpleado = CedulaEmpleado;
    }

    public int getCodigo_Empleado() {
        return Codigo_Empleado;
    }

    public void setCodigo_Empleado(int Codigo_Empleado) {
        this.Codigo_Empleado = Codigo_Empleado;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getCedulaEmpleado() {
        return CedulaEmpleado;
    }

    public void setCedulaEmpleado(String CedulaEmpleado) {
        this.CedulaEmpleado = CedulaEmpleado;
    }
    
}
