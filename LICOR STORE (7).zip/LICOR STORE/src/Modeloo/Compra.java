package Modeloo;

/*** @author Licoreria
 */
public class Compra {
    
}
